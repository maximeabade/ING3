# Attention

Je me suis permis de joindre une version modifiée du code python présent dans le noteboook, le rendant plus rapide en limitant le nombre d'epoch.
Cette réduction a pour conséquences une exécution SIGNIFICATIVEMENT plus rapide, mais une précision légèrement réduite.
Je vous invite à tester les deux versions pour vous faire une idée de la différence de performance.